# Space Waves

Space Waves is an arcade tunnel runner game with unlockable worlds and coin multipliers. Survive as long as you can, earn coins, and unlock new worlds with higher rewards!

## Features
- Multiple worlds with unique visuals and coin multipliers
- Shop system to unlock new worlds
- Skins for your core
- Local high score and coin saving

## How to Play
- Click or press Space/W/Up to thrust upward
- Avoid the tunnel walls
- Earn coins based on your score and world multiplier
- Unlock new worlds in the shop

## Run Locally
Just open `index.html` in your browser.

## License
MIT
